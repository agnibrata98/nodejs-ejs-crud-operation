const route = require('express').Router();
const appController = require('../controllers/app.controller');

route.get('/', appController.welcome);
route.get('/about-us', appController.about);

route.get('/form', appController.submitForm);

route.post('/submit-form', appController.showFormData);

route.get('/list', appController.getData);

route.get('/edit-employee/:id', appController.editData);

route.post('/update-form', appController.updateData);

route.get('/delete-employee/:id', appController.deleteData);

module.exports = route;